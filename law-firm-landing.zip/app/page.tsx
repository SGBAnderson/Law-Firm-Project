"use client"

import LawFirmLanding from "../landing-page"

export default function SyntheticV0PageForDeployment() {
  return <LawFirmLanding />
}